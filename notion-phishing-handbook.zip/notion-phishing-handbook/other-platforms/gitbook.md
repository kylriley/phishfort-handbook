# GitBook Takedowns

## Evidence Requirements

✅ **Full URL**
- Direct link to the infringing GitBook page.

✅ **Brief Explanation**
- Context of the attack.
- How it violates your brand.
- Type of infringement.

✅ **LOA**
- Letter of Authorization.

[Return to Home →](../)
